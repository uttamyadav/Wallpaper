<html>
   
   <head>
      <title>Add New Record in MySQL Database</title>
   </head>
   
   <body>
                    <?php
                    session_start();
                  if(isset($_SESSION['entry']))
                  {     
                    if(isset($_POST['submit']))
                    {
                        include_once("../Database/Database_Connection.php");

                        // Create connection
                        $conn = new mysqli($servername, $username, $password, $dbname);
                        // Check connection
                        if ($conn->connect_error) {
                            die("Connection failed: " . $conn->connect_error);
                        } 

                        $cat_name=$_POST['category_name'];
                        $album=$_POST['album_id'];
                        $thumimg=$_POST['thumbnail_img'];
                        $acount=$_POST['acoount_name'];

                        $sql = "INSERT INTO infotable (category_name, album_id, thumbnail_img,datasourceid)
                        VALUES ('$cat_name', '$album', '$thumimg','$acount')";

                        if ($conn->query($sql) === TRUE) {
                           ?>
                           <script type="text/javascript">
                            alert("New record created successfully");
                            </script>
                            <?php
                        } else {
                            echo "Error: " . $sql . "<br>" . $conn->error;
                        }

                        $conn->close();
                    }
                 }
                 else
                 {
                  header('Location:../access.php');
                 }
                    ?>
                 
            <a href="logout.php">Logout</a>
               <form method = "post" action = "enterdatasource.php" >
                  <table width = "400" border = "0" cellspacing = "1" 
                     cellpadding = "2">
                  
                     <tr>
                        <td >Category Name : </td>
                        <td><input name = "category_name" type = "text" ></td>
                     </tr>
                  
                     <tr>
                        <td >Album Id : </td>
                        <td><input name = "album_id" type = "text" ></td>
                     </tr>
                  
                     <tr>
                        <td >Thumbnail Image : </td>
                        <td><input name = "thumbnail_img" type = "text" ></td>
                     </tr>

                     <tr>
                        <td >Account Name :</td>
                        <td><input name = "acoount_name" type = "text" ></td>
                     </tr>
                  
                  
                     <tr>
                        <td> </td>
                        <td>
                           <input name = "submit" type = "submit" id = "submit" 
                              value = "Add Record">
                        </td>
                     </tr>
                  
                  </table>
                  <a href="../Api/Read_Data.php">Show Data</a>
                  
               </form>

            <h2>All Data of Yours.</h2>
            <?php
               $servername = "localhost";
               $username = "root";
               $password = "";
               $dbname = "galleryapi";

               // Create connection
               $conn = new mysqli($servername, $username, $password, $dbname);
               // Check connection
               if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
               } 

               $sql = "SELECT * FROM infotable";
               $result = $conn->query($sql);
               ?>
               <table border="10">
                  <th>Category Type</th>
                  <th>Album Id</th>
                  <th>Thunbnail Image</th>
                  <th>Account Type</th>
                  <th>Delete</th>
                  <tr>
               <?php
               if ($result->num_rows > 0) {
                // output data of each row
                while($row = $result->fetch_assoc())
               {
                  ?>
                  <tr>
                     
                     
                     <?php
                     echo "<td>".$row["category_name"]."</td><td>". $row["album_id"]."</td><td>".$row["thumbnail_img"]."</td><td>".$row["datasourceid"]."</td>";
                     ?>
                     <td> <a href='delete.php?id=<?php echo $row['id'];?>'>Delete </a> </td>

                     <?php
               
                     ?>
                     
                  </tr>
                  <?php
                }
               } else {
                echo "No Data is There";
               }
               ?>
            </tr>
               </table>

               <?php
                $conn->close();
            ?> 

        
   
   </body>
</html>